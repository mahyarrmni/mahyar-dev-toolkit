# نحوه‌ی ایمپورت (نسخه‌ی نهایی v2)

محتوای `github-import/` همان ساختار قبلی است: هر پوشه یک ریپو.

| پوشه | ریپوی گیت‌هاب | وضعیت |
|---|---|---|
| `python-toolkit/` | ریپوی `python-toolkit` | **به‌روز**: ۵ ابزار جدید (SEO Audit Bot، Keyword Miner، Maps Leads Bot، B2B Lead Intelligence، FileSage)، README دوزبانه برای همه‌ی ابزارها، سطح ریسک و سلب مسئولیت |
| `404-radar/` | ریپوی **جدید** `404-radar` | پلاگین جدید + README دوزبانه + `uninstall.php` + CI |
| `backlink-pilot/` … `bulk-image-alt/` (۸ پلاگین) | ریپوهای موجود هم‌نام | README دوزبانه‌ی کامل با هشدار ریسک؛ چند اصلاح کد (پایین) |
| `mahyarrmni/` | ریپوی پروفایل | **به‌روز**: جدول پلاگین‌ها و ابزارها با سطح ریسک + بخش سلب مسئولیت |

## ریپوی جدید (python-toolkit و 404-radar)
```bash
cd python-toolkit
git init -b main && git add . && git commit -m "Initial import: toolkit v1.1.0"
gh repo create mahyarrmni/python-toolkit --public --source . --push
# همین‌طور برای 404-radar
```

## ریپوهای پلاگین موجود (مثال: seo-intelligence)
```bash
git clone https://github.com/mahyarrmni/seo-intelligence tmp && cd tmp
cp -r ../seo-intelligence/. .
git add -A && git commit -m "Docs: bilingual README, risk notice, integrity guard" && git push
```
(پوشه‌ی `.git` دست‌نخورده می‌ماند؛ فقط فایل‌ها روی ریپوی کلون‌شده کپی می‌شوند.)

## ⚠️ قبل از push حتماً بخوان
1. **seo-intelligence و content-cannibalization-scanner در این زیپ ناقص‌اند.** فقط فایل اصلی را دارند، ولی کد به `includes/` (و `admin/`، `tools/`) نیاز دارد که در زیپ نبود.
   روش `cp -r` بالا فقط روی ریپوی کامل کلون‌شده امن است (پوشه‌های موجود را حذف نمی‌کند). **هرگز این پوشه‌ها را به‌جای ریپوی اصلی نگذار/ZIP نصبی از روی همین زیپ نساز.**
   برای seo-intelligence یک گارد اضافه کردم تا در نبود فایل‌ها به‌جای خطای مرگبار، اعلان نشان دهد.
2. من PHP روی سیستم نداشتم؛ تغییرات کد PHP فقط با بررسی دستی و شمارش پرانتز/آکولاد کنترل شده، نه اجرا. **قبل از انتشار روی یک وردپرس تست امتحان کن.**
3. تست‌های `b2b_lead_intel`: ۱۱ تست واحد پاس شدند؛ ۲ تست end-to-end به `aiohttp` نیاز دارند که اینجا نصب نبود (در CI نصب می‌شود).

## تغییرات کد (کوچک و عمدی)
| فایل | تغییر |
|---|---|
| `phone-number-changer` | شماره‌های موبایل واقعی‌نما داخل کامنت و placeholder با شماره‌ی نمونه عوض شد |
| `smart-alt-setter`, `bulk-image-alt` | افزودن nonce/CSRF، بررسی دسترسی، sanitize/escape، حذف آیکون لینک‌شده از toopgame.ir؛ توضیح افزونه با رفتار واقعی هماهنگ شد؛ نسخه ۱٫۱٫۰ و ۱٫۳٫۰ |
| `ai-comment-seeder` | پیش‌فرض `auto_approve` از روشن به **خاموش** (کامنت‌ها در انتظار تأیید می‌مانند) |
| `seo-intelligence` | گارد یکپارچگی فایل‌ها |
| `404-radar` | هدر (سازنده، نسخه‌ها) و `uninstall.php` |
| `python-toolkit/utilities` | حذف لوگوی لینک‌شده و متن واترمارک پیش‌فرض (نام سایت) در image_optimizer؛ کلمات کلیدی پیش‌فرض حوزه‌ی حقوقی در auto_image_downloader خنثی شد |

## چیزهایی که عمداً داخل نیستند
- **فایل‌های Search Console** (`*-Performance-on-Search-*.zip/xlsx`) و گزارش‌های کلمات کلیدی (`t__1_.html`, `t__2_.html`): داده‌ی خصوصی سایت‌ها/مشتری‌ها و کلمات کلیدی‌اند؛ داخل ریپو نیامدند. در `.gitignore` هم خروجی‌های مشابه نادیده گرفته می‌شوند.
- **ابزارهای CTR Bot، BacklinkBomber، کامنت‌بات و جستجوی پروکسی**: نسخه‌ی کدشان در آپلودها نبود و پروفایل دیگر لینکشان نمی‌دهد (دلیل: `python-toolkit/docs/RESPONSIBLE_USE.md`). اگر ریپوهای قدیمی‌شان عمومی‌اند، private/archive کن و رمز کامیت‌شده در تاریخچه را «لو رفته» فرض کن.

## بعد از ایمپورت
1. GitHub Actions را در هر ریپو فعال کن.
2. فایل `LICENSE` پلاگین‌ها را با *Add file → license → GPL-2.0* اضافه کن (متن GPL داخل بسته نیست).
3. سه ایمیج/اسکرین‌شات نمونه برای README ها اضافه کن (اختیاری).
